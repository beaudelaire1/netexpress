"""Service layer pour l'application ``core``.

Ce package héberge des services transverses (PDF, emails, etc.) qui ne
doivent pas vivre dans les vues ou les modèles.
"""
