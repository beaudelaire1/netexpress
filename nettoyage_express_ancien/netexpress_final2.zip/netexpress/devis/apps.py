from django.apps import AppConfig


class DevisConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "devis"
    verbose_name = "Devis"