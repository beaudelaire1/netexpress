"""
Configuration de l'administration pour l'app ``contact``.

Enregistre le modèle ``Message`` et fournit une vue en liste filtrable et
recherchable par sujet, nom ou email.  Le champ ``processed`` est éditable
directement depuis la liste afin de marquer les messages comme traités.
"""

from django.contrib import admin

from .models import Message


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "topic", "created_at", "processed")
    list_filter = ("topic", "processed", "created_at")
    search_fields = ("full_name", "email", "body")
    list_editable = ("processed",)
    readonly_fields = ("created_at", "ip")