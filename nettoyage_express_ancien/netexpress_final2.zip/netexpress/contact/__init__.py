"""App pour la gestion des messages de contact.

Elle permet aux visiteurs d'envoyer des demandes via le formulaire de
contact et enregistre chaque message avec la date, le sujet et les
coordonnées de l'expéditeur.  Une notification par e‑mail peut être
envoyée à l'administrateur et une copie au client, selon les paramètres
du site.
"""