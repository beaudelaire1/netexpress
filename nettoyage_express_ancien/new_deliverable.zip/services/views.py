"""
Views for services catalogue.

Provides a list view displaying all active services and a detail view for an
individual service, including the checklist of tasks.  Using Django's
generic class-based views simplifies the code and makes it easy to extend.
"""

from django.views.generic import ListView, DetailView

from .models import Service


class ServiceListView(ListView):
    model = Service
    template_name = "services/service_list.html"
    context_object_name = "services"

    def get_queryset(self):
        return Service.objects.filter(is_active=True)


class ServiceDetailView(DetailView):
    model = Service
    template_name = "services/service_detail.html"
    context_object_name = "service"