"""App initialization for the services catalogue."""
