"""
Models for the services catalogue.

This module defines the ``Service`` model, which encapsulates the details of each
service offering, including a category, pricing information, descriptive text
and a hero image.  A ``ServiceTask`` model provides a flexible checklist of
operations associated with each service (e.g. "Débroussaillage", "Taille haies").

By adopting explicit choices for the category field and normalising the tasks
into their own model, we make it easy to categorize and display services in a
user friendly manner.
"""

from django.db import models
from django.utils.text import slugify


class Service(models.Model):
    class Category(models.TextChoices):
        ESPACES_VERTS = 'espaces_verts', 'Espaces verts'
        NETTOYAGE = 'nettoyage', 'Nettoyage'
        PEINTURE = 'peinture', 'Peinture'
        BRICOLAGE = 'bricolage', 'Bricolage'

    title = models.CharField(max_length=200, unique=True)
    category = models.CharField(
        max_length=20,
        choices=Category.choices,
        default=Category.ESPACES_VERTS,
        help_text="Catégorie du service"
    )
    description = models.TextField(blank=True)
    short_description = models.CharField(
        max_length=255,
        blank=True,
        help_text="Description courte utilisée sur la page d'accueil."
    )
    base_price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Prix de base en euros pour ce service."
    )
    duration_minutes = models.PositiveIntegerField(
        default=60,
        help_text="Durée estimée en minutes pour exécuter ce service."
    )
    image = models.ImageField(
        upload_to="services",
        blank=True,
        null=True,
        help_text="Image illustrative du service."
    )
    is_active = models.BooleanField(default=True)
    slug = models.SlugField(
        max_length=200,
        unique=True,
        help_text="Identifiant d'URL généré automatiquement."
    )

    class Meta:
        ordering = ["title"]
        verbose_name = "service"
        verbose_name_plural = "services"

    def __str__(self) -> str:
        return self.title

    def save(self, *args, **kwargs):
        # Automatically generate slug on first save if not provided
        if not self.slug:
            self.slug = slugify(self.title, allow_unicode=True)
        super().save(*args, **kwargs)


class ServiceTask(models.Model):
    """Checklist item associated with a service."""
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="tasks")
    name = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "id"]
        verbose_name = "tâche"
        verbose_name_plural = "tâches"

    def __str__(self) -> str:
        return self.name