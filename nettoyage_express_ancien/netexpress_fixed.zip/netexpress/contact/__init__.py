"""
Initialisation de l'application ``contact``.

Cette app collecte les messages envoyés via le formulaire de contact et
les stocke dans la base.  La refonte de 2025 rend le champ téléphone
obligatoire et aligne la mise en page sur la nouvelle charte.  Les
illustrations présentes sur le site sont issues de la plateforme
Unsplash pour respecter les droits d'auteur tout en offrant un rendu
professionnel【668280112401708†L16-L63】.
"""