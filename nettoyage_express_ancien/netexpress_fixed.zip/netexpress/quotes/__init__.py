"""
Application ``quotes`` (legacy).

Cette application conserve la version anglophone des demandes de devis.
Elle subsiste pour compatibilité avec des projets existants mais a été
mise à jour en 2025 pour rendre le champ téléphone obligatoire et
harmoniser l’interface avec les nouvelles pages NetExpress.  Les
illustrations utilisées sont issues d'Unsplash【668280112401708†L16-L63】.
"""