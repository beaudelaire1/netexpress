"""
Migrations package pour l’app ``Service`` (héritée).

Ce package contient les fichiers de migration générés par Django pour
créer les tables associées au modèle ``Service``.  Il est maintenu pour
assurer la compatibilité avec les projets existants mais n’est plus
recommandé pour les nouveaux développements (utilisez plutôt l’app
``services``).
"""