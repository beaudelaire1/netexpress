"""
Routes URL pour l'app ``contact``.

Une seule route est exposée afin de servir le formulaire de contact.  Le
nom de l'espace de noms est ``contact`` pour faciliter les appels via
``{% url %}`` dans les templates.
"""

from django.urls import path
from . import views

app_name = "contact"

urlpatterns = [
    path("", views.contact_view, name="contact"),
]