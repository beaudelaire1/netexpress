"""
Core application views.

The home view renders the landing page with a selection of featured services.
The health view is used by monitoring tools to verify the application is
responding properly.
"""

from django.shortcuts import render
from django.http import JsonResponse
from services.models import Service, Category


def home(request):
    """
    Render the landing page. A handful of active services are selected to be
    displayed as highlights.  Adjust the number of services shown here to
    customise the homepage.
    """
    # Fetch a few active services to showcase on the homepage. We also
    # retrieve all service categories to display a "Nos métiers" section.
    featured = Service.objects.filter(is_active=True).order_by("title")[:6]
    categories = Category.objects.all().order_by("name")
    return render(request, "home.html", {
        "featured_services": featured,
        "categories": categories,
    })


def about(request):
    """
    Render a simple "À propos" page describing the company.  This page
    outlines the mission, values et l’historique de l’entreprise selon le
    cahier de charge.  It can be customised in the template
    ``core/about.html``.
    """
    return render(request, "core/about.html")


def health(request):
    """Simple JSON endpoint used by uptime probes to check application health."""
    return JsonResponse({"status": "ok"})