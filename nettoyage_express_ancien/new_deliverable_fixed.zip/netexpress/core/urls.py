from django.urls import path
from . import views


app_name = "core"
urlpatterns = [
path("", views.home, name="home"),
path("health/", views.health, name="health"),
    # Page "À propos" selon le cahier des charges
    path("a-propos/", views.about, name="about"),
]