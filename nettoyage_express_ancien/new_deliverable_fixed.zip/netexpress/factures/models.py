"""
Modèles pour la gestion des factures.

Une facture est créée à partir d'un devis une fois que le client accepte l'offre.
Chaque facture possède un numéro unique, un montant et un PDF généré à partir
des données de facturation.  Le modèle ``generate_pdf`` s'appuie sur
ReportLab pour créer un document professionnel.

Cette version simple ne gère pas les lignes multiples ni les dates d'échéance,
mais pose les bases pour les étendre selon le cahier des charges.
"""

import io
from decimal import Decimal
from datetime import datetime

from django.db import models
from django.core.files.base import ContentFile

from devis.models import Quote


class Invoice(models.Model):
    quote = models.ForeignKey(Quote, on_delete=models.CASCADE, related_name="factures", null=True, blank=True)
    number = models.CharField(max_length=50, unique=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    created_at = models.DateTimeField(auto_now_add=True)
    pdf = models.FileField(upload_to="factures", blank=True, null=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "facture"
        verbose_name_plural = "factures"
        indexes = [models.Index(fields=["number", "created_at"])]

    def __str__(self) -> str:
        return f"Facture {self.number} pour {self.quote.client.full_name if self.quote else 'N/A'}"

    def generate_number(self) -> str:
        """Générer un numéro de facture simple basé sur la date et l'ID."""
        date_part = self.created_at.strftime("%Y%m%d") if self.created_at else datetime.now().strftime("%Y%m%d")
        return f"F-{date_part}{self.pk or ''}"

    def generate_pdf(self):
        """
        Créer un PDF représentant la facture à l'aide de ReportLab.

        Le PDF inclut le nom de l'entreprise, les coordonnées du client et
        la description du service.  Pour des exigences plus complexes (lignes
        multiples, totaux HT/TVA/TTC, conditions générales), ajustez cette
        méthode en conséquence.
        """
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.pdfgen import canvas
            from reportlab.lib.units import mm
        except ImportError as exc:
            raise ImportError(
                "ReportLab n'est pas installé. Ajoutez reportlab à vos dépendances pour générer des factures PDF."
            ) from exc

        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        width, height = A4

        # En-tête
        c.setFont("Helvetica-Bold", 16)
        c.drawString(20 * mm, height - 30 * mm, "NetExpress")
        c.setFont("Helvetica", 10)
        c.drawString(20 * mm, height - 40 * mm, "Entreprise de nettoyage et entretien")
        c.drawString(20 * mm, height - 45 * mm, "contact@netexpress.test")

        # Infos client
        if self.quote:
            c.setFont("Helvetica-Bold", 12)
            c.drawString(20 * mm, height - 60 * mm, "Facturé à :")
            c.setFont("Helvetica", 10)
            c.drawString(20 * mm, height - 65 * mm, self.quote.client.full_name)
            c.drawString(20 * mm, height - 70 * mm, self.quote.client.email)
            c.drawString(20 * mm, height - 75 * mm, self.quote.client.phone)

        # Détails facture
        c.setFont("Helvetica-Bold", 14)
        c.drawString(120 * mm, height - 30 * mm, f"Facture {self.number}")
        c.setFont("Helvetica", 10)
        invoice_date = self.created_at.strftime("%d/%m/%Y") if self.created_at else datetime.now().strftime("%d/%m/%Y")
        c.drawString(120 * mm, height - 35 * mm, f"Date : {invoice_date}")

        # Résumé du service
        c.setFont("Helvetica-Bold", 12)
        c.drawString(20 * mm, height - 90 * mm, "Description")
        c.drawString(150 * mm, height - 90 * mm, "Montant (€)")
        c.setFont("Helvetica", 10)
        y = height - 100 * mm
        description = "Service sur mesure"
        if self.quote and self.quote.service:
            description = self.quote.service.title
        c.drawString(20 * mm, y, description)
        c.drawString(150 * mm, y, f"{self.amount:.2f}")

        # Total
        c.setFont("Helvetica-Bold", 12)
        c.drawString(20 * mm, y - 15 * mm, "Total")
        c.drawString(150 * mm, y - 15 * mm, f"{self.amount:.2f}")

        c.showPage()
        c.save()

        pdf_content = buffer.getvalue()
        buffer.close()
        filename = f"facture_{self.number}.pdf"
        self.pdf.save(filename, ContentFile(pdf_content), save=False)