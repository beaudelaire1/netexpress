"""
Vues pour la génération et la livraison de factures.

Ces vues sont protégées par le décorateur ``staff_member_required`` afin
d'empêcher l'accès public.  Elles permettent de créer une facture à partir
d'un devis et de télécharger le PDF généré.
"""

from decimal import Decimal

from django.shortcuts import get_object_or_404, redirect
from django.http import FileResponse, Http404
from django.contrib.admin.views.decorators import staff_member_required
from django.urls import reverse

from devis.models import Quote
from .models import Invoice


@staff_member_required
def create_invoice(request, quote_id):
    """
    Créer une facture pour le devis donné.

    Si une facture existe déjà pour ce devis, elle est réutilisée.  Sinon
    une nouvelle facture est créée avec un montant par défaut.  Le PDF est
    généré avant la redirection vers l'URL de téléchargement de la facture.
    """
    quote = get_object_or_404(Quote, pk=quote_id)
    invoice, created = Invoice.objects.get_or_create(quote=quote, defaults={"amount": Decimal("0.00")})
    if not invoice.number:
        invoice.number = invoice.generate_number()
    # Utiliser un montant par défaut; dans une appli réelle, calculez-le à partir du devis
    if not invoice.amount or invoice.amount == Decimal("0.00"):
        invoice.amount = Decimal("100.00")  # valeur de substitution
    invoice.generate_pdf()
    invoice.save()
    return redirect(reverse("factures:download", args=[invoice.pk]))


@staff_member_required
def download_invoice(request, pk):
    """
    Servir le fichier PDF associé à la facture.

    Lève une 404 si la facture n'existe pas ou si le PDF n'a pas été généré.
    """
    invoice = get_object_or_404(Invoice, pk=pk)
    if not invoice.pdf:
        raise Http404("Cette facture n'a pas encore été générée.")
    response = FileResponse(invoice.pdf.open("rb"), filename=invoice.pdf.name, as_attachment=True)
    return response