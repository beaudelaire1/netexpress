"""
Admin registration for services and tasks.

This module configures how services and their associated tasks appear in the
Django admin.  Jazzmin will apply modern styling automatically.  By using
inline editing for tasks, administrators can easily manage the checklist
associated with each service.
"""

from django.contrib import admin
from .models import Category, Service, ServiceTask


class ServiceTaskInline(admin.TabularInline):
    model = ServiceTask
    extra = 1


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ("title", "category", "base_price", "duration_minutes", "is_active")
    list_filter = ("category", "is_active")
    search_fields = ("title", "description", "short_description")
    prepopulated_fields = {"slug": ("title",)}
    inlines = [ServiceTaskInline]

# Register Category so administrators can manage top‑level categories.
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    search_fields = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}