"""
URL configuration for services.
Defines routes for listing services and viewing service detail pages.  The
namespace ``services`` is used so that template tags can refer to these
URLs without ambiguity.
"""

from django.urls import path
from . import views

app_name = "services"

urlpatterns = [
    path("", views.ServiceListView.as_view(), name="list"),
    path("<slug:slug>/", views.ServiceDetailView.as_view(), name="detail"),
]