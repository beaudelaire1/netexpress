"""
Models for the services catalogue.

This module defines the following entities:

* ``Category``: a top‑level classification for services, with a slug (used in
  URLs and filters), a human‑readable name and an optional icon reference.
* ``Service``: a description of an offering the company provides, including
  its category, pricing information, descriptive text, hero image, and an
  activation flag.  A ``created_at`` field tracks when the service was
  published.  Services belong to a category via a foreign key.
* ``ServiceTask``: a checklist item associated with a service (e.g.
  ``Débroussaillage``, ``Taille haies``).  Tasks are ordered and can be
  displayed on the service detail page.

These models intentionally avoid baking business logic into enums; instead,
categories are separate objects that can be managed via the admin.  This
structure matches the cahier des charges requiring categories by métiers
(espaces verts, nettoyage, peinture, bricolage) and provides flexibility for
future additions.
"""

from django.db import models
from django.utils.text import slugify


class Category(models.Model):
    """High‑level classification for services (e.g. espaces verts, nettoyage).

    The ``slug`` is used in URLs and filters, while ``name`` is displayed to
    end‑users.  An optional ``icon`` field can store the name of an icon or
    an SVG reference.  Categories are editable via the admin and used as
    foreign keys on ``Service`` objects.
    """

    slug = models.SlugField(max_length=50, unique=True)
    name = models.CharField(max_length=100)
    icon = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "catégorie"
        verbose_name_plural = "catégories"

    def __str__(self) -> str:
        return self.name


class Service(models.Model):
    title = models.CharField(max_length=200, unique=True)
    category = models.ForeignKey(
        Category,
        on_delete=models.CASCADE,
        related_name="services",
        help_text="Catégorie du service"
    )
    description = models.TextField(blank=True)
    short_description = models.CharField(
        max_length=255,
        blank=True,
        help_text="Description courte utilisée sur la page d'accueil."
    )
    base_price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Prix de base en euros pour ce service."
    )
    duration_minutes = models.PositiveIntegerField(
        default=60,
        help_text="Durée estimée en minutes pour exécuter ce service."
    )
    image = models.ImageField(
        upload_to="services",
        blank=True,
        null=True,
        help_text="Image illustrative du service."
    )
    is_active = models.BooleanField(default=True)
    slug = models.SlugField(
        max_length=200,
        unique=True,
        help_text="Identifiant d'URL généré automatiquement."
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["title"]
        verbose_name = "service"
        verbose_name_plural = "services"
        indexes = [
            models.Index(fields=["slug"]),
            models.Index(fields=["is_active"]),
        ]

    def __str__(self) -> str:
        return self.title

    def save(self, *args, **kwargs):
        # Automatically generate slug on first save if not provided
        if not self.slug:
            self.slug = slugify(self.title, allow_unicode=True)
        super().save(*args, **kwargs)


class ServiceTask(models.Model):
    """Checklist item associated with a service."""
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="tasks")
    name = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "id"]
        verbose_name = "tâche"
        verbose_name_plural = "tâches"

    def __str__(self) -> str:
        return self.name