"""
Configuration de l'administration pour l'app ``devis``.

Les listes affichent les devis avec le numéro, le client, le service et le
statut.  On ajoute également le modèle ``Client`` pour gérer les fiches
clients depuis l'interface d'administration.  Les filtres et champs de
recherche facilitent la gestion commerciale.
"""

from django.contrib import admin

from .models import Client, Quote


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "phone", "created_at")
    search_fields = ("full_name", "email", "phone")
    list_filter = ("created_at",)


@admin.register(Quote)
class QuoteAdmin(admin.ModelAdmin):
    list_display = ("number", "client", "service", "status", "created_at")
    list_filter = ("status", "created_at")
    search_fields = ("number", "client__full_name", "client__email")
    readonly_fields = ("created_at",)
    list_editable = ("status",)