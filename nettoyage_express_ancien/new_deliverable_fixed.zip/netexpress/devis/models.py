"""
Modèles pour la gestion des devis.

Cette app gère les entités suivantes :

* ``Client``: représente un contact (particulier ou entreprise) qui demande un devis.
  Les champs incluent nom complet, email, téléphone et adresse.  Cette
  entité peut être enrichie selon les besoins (ex. société, SIREN).

* ``Quote``: une demande de devis associée à un client.  Elle contient un
  numéro unique, un statut et des champs pour le service souhaité, un message
  libre et des totaux (HT, TVA, TTC) pour préparer la conversion en
  facture.  Les totaux ne sont pas calculés automatiquement dans cette
  version simplifiée mais peuvent être renseignés manuellement via l'admin.

Les index sur ``number`` et ``created_at`` facilitent les recherches et
ordonnancements dans l'interface d'administration.
"""

from decimal import Decimal
from django.db import models
from django.utils.text import slugify
from services.models import Service


class Client(models.Model):
    """Informations de contact pour une demande de devis."""
    full_name = models.CharField(max_length=200)
    email = models.EmailField()
    phone = models.CharField(max_length=50)
    address_line = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100, blank=True)
    zip_code = models.CharField(max_length=20, blank=True)
    company = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "client"
        verbose_name_plural = "clients"

    def __str__(self) -> str:
        return self.full_name


class Quote(models.Model):
    """Demande de devis.

    Un numéro de devis est généré automatiquement à partir de l'année et de
    l'identifiant.  Le champ ``service`` est optionnel pour permettre des
    demandes libres.  Le statut permet de suivre l'avancement (brouillon,
    envoyé, accepté, rejeté).  Les totaux permettent d'anticiper la facture.
    """

    STATUS_CHOICES = [
        ("draft", "Brouillon"),
        ("sent", "Envoyé"),
        ("accepted", "Accepté"),
        ("rejected", "Rejeté"),
    ]

    number = models.CharField(max_length=20, unique=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name="quotes")
    service = models.ForeignKey(Service, on_delete=models.SET_NULL, null=True, blank=True, related_name="quotes")
    message = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")
    valid_until = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    total_ht = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    tva = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    total_ttc = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "devis"
        verbose_name_plural = "devis"
        indexes = [models.Index(fields=["number", "created_at"])]

    def __str__(self) -> str:
        return f"Devis {self.number or ''} pour {self.client.full_name}"

    def save(self, *args, **kwargs):
        if not self.number:
            # Generate a simple number: Q-YYYY-#### where #### is the pk once saved
            year = self.created_at.year if self.created_at else None
            prefix = f"Q-{year}-" if year else "Q-"
            # Temporarily set number to ensure unique constraint; will be overwritten after save
            self.number = prefix
            super().save(*args, **kwargs)
            self.number = f"{prefix}{self.pk:04d}"
            # Save again with final number
            return self.save()
        return super().save(*args, **kwargs)