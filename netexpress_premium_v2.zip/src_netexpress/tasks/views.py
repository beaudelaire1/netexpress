"""Vues pour le suivi des tâches (class-based views)."""

from datetime import timedelta

from django.http import JsonResponse
from django.views.decorators.http import require_GET
from django.views.generic import ListView, DetailView, TemplateView

from .models import Task


class TaskListView(ListView):
    """Liste toutes les tâches pour le tableau de bord opérationnel."""
    model = Task
    template_name = "tasks/task_list.html"
    context_object_name = "tasks"
    ordering = ["-created_at"]


class TaskDetailView(DetailView):
    """Affiche le détail d'une tâche individuelle."""
    model = Task
    template_name = "tasks/task_detail.html"
    context_object_name = "task"


class TaskCalendarView(TemplateView):
    """Vue calendrier mensuel (FullCalendar) pour les tâches."""
    template_name = "tasks/task_calendar.html"


@require_GET
def task_events(request):
    """Retourne les tâches au format FullCalendar."""
    events = []
    from datetime import date
    today = date.today()
    for t in Task.objects.all():
        # Couleurs (demandes projet)
        # rouge: en retard | bleu: terminé | orange: presque en retard | jaune: proche | vert: ok
        color = "#2d8a5e"  # vert
        if t.status == Task.STATUS_COMPLETED:
            color = "#2563eb"  # bleu
        elif t.status == Task.STATUS_OVERDUE:
            color = "#dc2626"  # rouge
        else:
            try:
                remaining = (t.due_date - today).days if t.due_date else 999
            except Exception:
                remaining = 999
            if remaining <= 1 or t.status == Task.STATUS_ALMOST_OVERDUE:
                color = "#f59e0b"  # orange
            elif remaining <= 3:
                color = "#facc15"  # jaune
            else:
                color = "#2d8a5e"  # vert
        start = t.start_date
        end = (t.due_date + timedelta(days=1)) if t.due_date else (start + timedelta(days=1))
        events.append({
            "id": t.pk,
            "title": t.title,
            "start": start.isoformat() if start else None,
            "end": end.isoformat() if end else None,
            "url": t.get_absolute_url(),
            "backgroundColor": color,
            "borderColor": color,
        })
    return JsonResponse(events, safe=False)
