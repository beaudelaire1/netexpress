"""
Migrations package pour l’app ``core``.

Les fichiers de migration sont générés automatiquement par Django
et versionnés afin de reproduire la structure de base de données.
Ce fichier sert de point d’entrée au package.
"""