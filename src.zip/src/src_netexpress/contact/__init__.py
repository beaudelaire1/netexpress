"""
Initialisation de l'application ``contact``.

Cette app collecte les messages envoyés via le formulaire de contact et
les stocke dans la base.  La refonte de 2025 rend le champ téléphone
obligatoire et aligne la mise en page sur la nouvelle charte.  Les
    illustrations présentes sur le site proviennent désormais du dossier
    local ``static/img``.  En supprimant la dépendance à Unsplash,
    l'application garantit un rendu professionnel tout en évitant les
    appels vers des services externes【668280112401708†L16-L63】.
"""