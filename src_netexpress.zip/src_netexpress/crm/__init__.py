"""
CRM application for NetExpress.

This app centralises customer management by providing a single
``Customer`` model that captures all client information needed
throughout the ERP.  It unifies data that was previously scattered
between various apps (notably ``devis.Client`` and ``accounts.Profile``).

Compatibility note:
    For Django versions prior to 3.2, the default application
    configuration must be specified explicitly via the
    ``default_app_config`` variable.  Even though Django 3.2+ will
    automatically discover ``AppConfig`` subclasses, defining this
    variable helps avoid issues where the ``crm`` app is not
    recognized (``LookupError: No installed app with label 'crm'``).
    See the Django documentation for details.
"""

# Explicitly specify the default application configuration for this
# app.  This ensures that Django registers ``crm.apps.CrmConfig`` as
# the configuration class even in environments that do not auto-
# discover AppConfig subclasses (e.g. Django < 3.2).  Without this,
# migrations may fail with LookupError if Django cannot locate the
# ``crm`` app.
default_app_config = "crm.apps.CrmConfig"
