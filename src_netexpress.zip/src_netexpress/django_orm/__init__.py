"""Adapters using the Django ORM.

This package contains concrete implementations of repository ports
leveraging the Django ORM for persistence.
"""
