from .base import * # noqa
DEBUG = True