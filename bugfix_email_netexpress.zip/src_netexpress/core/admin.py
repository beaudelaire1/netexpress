"""
Configuration de l'interface d'administration pour l'application ``core``.

Aucun modèle n'est actuellement géré par cette application.  Ce module
reste néanmoins présent pour permettre l'enregistrement de futurs modèles.
"""

from django.contrib import admin  # import conservé pour compatibilité future

__all__ = []
